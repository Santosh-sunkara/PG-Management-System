// src/pages/Bookmarks.jsx
import { useMemo, useState } from "react";
import "../components/Bookmark.css";
const seed = [
  { id: 1, name: "AML Report Jan", category: "AML Reports", type: "PDF", status: "Generated" },
  { id: 2, name: "Risk Report Feb", category: "Risk Reports", type: "PDF", status: "Generated" },
  { id: 3, name: "Customer Report Mar", category: "Customer Reports", type: "PDF", status: "Generated" },
];

export default function Bookmarks() {
  const [q, setQ] = useState("");
  const [cat, setCat] = useState("");
  const [status, setStatus] = useState("");
  const [sortAsc, setSortAsc] = useState(true);

  const filtered = useMemo(() => {
    let rows = seed;
    if (cat) rows = rows.filter(r => r.category === cat);
    if (status) rows = rows.filter(r => r.status === status);
    if (q) rows = rows.filter(r => r.name.toLowerCase().includes(q.toLowerCase()));
    rows = [...rows].sort((a,b)=> sortAsc ? a.id-b.id : b.id-a.id);
    return rows;
  }, [q, cat, status, sortAsc]);

  return (
    <div className="card">
      <div className="card-body">
        <div className="d-flex align-items-center justify-content-between mb-3">
          <h5 className="mb-0">MyBookMarks</h5>
          <button className="btn btn-green">Bookmark Selected</button>
        </div>

        <div className="row g-2 filter-bar mb-3">
          <div className="col-12 col-md-3">
            <input className="form-control" placeholder="MM/YY → MM/YY" />
          </div>
          <div className="col-6 col-md-3">
            <select className="form-select" value={cat} onChange={e=>setCat(e.target.value)}>
              <option value="">Category</option>
              <option>AML Reports</option>
              <option>Risk Reports</option>
              <option>Customer Reports</option>
            </select>
          </div>
          <div className="col-6 col-md-3">
            <select className="form-select" value={status} onChange={e=>setStatus(e.target.value)}>
              <option value="">Status</option>
              <option>Generated</option>
              <option>Queued</option>
            </select>
          </div>
          <div className="col-12 col-md-3">
            <input
              className="form-control"
              placeholder="Search Report"
              value={q}
              onChange={e=>setQ(e.target.value)}
            />
          </div>
        </div>

        <div className="table-responsive">
          <table className="table align-middle">
            <thead>
              <tr>
                <th style={{width: 60}} className="text-nowrap">
                  <button
                    className="btn btn-sm btn-outline-secondary"
                    onClick={()=>setSortAsc(s=>!s)}
                    title="Sort"
                  >
                    Sort {sortAsc ? "↑" : "↓"}
                  </button>
                </th>
                <th>ID</th>
                <th>Report Name</th>
                <th>Category</th>
                <th>File Type</th>
                <th>Status</th>
                <th className="text-center">View/Download</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map(r=>(
                <tr key={r.id}>
                  <td>
                    <input type="checkbox" aria-label={`select-${r.id}`} />
                  </td>
                  <td>{r.id}</td>
                  <td>{r.name}</td>
                  <td>{r.category}</td>
                  <td>{r.type}</td>
                  <td><span className="badge text-bg-success">Generated</span></td>
                  <td className="text-center">
                    <div className="btn-group">
                      <button className="btn btn-sm btn-outline-secondary" title="View">👁️</button>
                      <button className="btn btn-sm btn-outline-secondary" title="Download">⬇️</button>
                    </div>
                  </td>
                </tr>
              ))}
              {filtered.length === 0 && (
                <tr><td colSpan="7" className="text-center small-muted py-4">No results</td></tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
