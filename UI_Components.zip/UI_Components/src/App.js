import { BrowserRouter as Router, Routes, Route, Navigate } from "react-router-dom";


import LandingPage from "./components/LandingPage";
import RolePage from "./components/RolePage";
import Userlogin from "./components/Userlogin";
import CreateAccount from "./components/CreateAccount";
import Adminlogin from "./components/Adminlogin";
import ForgotPassword from "./components/ForgotPassword";
import AdminSettingsUI from './components/AdminSettings'
import { useState } from "react";
import Form from './components/Form';
import Details from './components/Details';
import ReportsPage from "./pages/ReportsPage";
//import AdminLayout from "./layouts/AdminLayout";
//import ReportAccess from "./pages/ReportAccess";
import ResetPassword from "./components/ResetPassword";
import UserDashboard from "./components/UserDashboard";

import Settings from "./components/Settings";
import AdminDashboard from "./components/AdminDashboard";
import Layout2 from "./components/Layout2";
import Bookmarks from "./pages/Bookmarks";


import Profile from "./pages/Profile";
import ReportAccess from "./pages/ReportAccess";


function App() {
  const [data, setData] = useState([])
  return (
    <Router>
      <Routes>
        <Route path="/" element={<LandingPage />} />
        <Route path="/role-selection" element={<RolePage />} />
        <Route path="/Userlogin" element={<Userlogin />} />
        <Route path="/CreateAccount" element={<CreateAccount />} />
        <Route path="/Adminlogin" element={<Adminlogin />} />
        <Route path="/ForgotPassword" element={<ForgotPassword />} />
        <Route path="/AdminUser" element={<Form data={data} setData={setData} />} />
        <Route path="/details" element={<Details data={data} setData={setData} />} />
        <Route path='/settings' element={<AdminSettingsUI />} />
        <Route path="/Reports" element={<ReportsPage />} />
        {/* <Route  element={<Navigate to="/admin/report-access" replace />} />
      <Route element={<AdminLayout />}>
        {/* You can add more admin pages here */}
        {/* <Route path="/admin/report-access" element={<ReportAccess />} /> */}
        <Route path="/ResetPassword" element={<ResetPassword />} />
        <Route path="/UserDashboard" element={<UserDashboard />} />
        <Route path="/AdminDashboard" element={<AdminDashboard />} />
        <Route path="/UserSettings" element={<Settings />} />
        <Route element={<Layout2 />}>
        
        <Route path="/bookmarks" element={<Bookmarks />} />
       
        
        <Route path="/UserProfile" element={<Profile />} />
        
      
  </Route>
  <Route path="/ReportAccess" element={<ReportAccess />} />
      </Routes>
    </Router>
  );
}

export default App;
