// src/components/Sidebar.jsx
import "./Bookmark.css";
export default function Sidebar2() {
  return (
    <aside className="sidebar">
      <h6>Quick Access</h6>
      <div className="list-group mb-3">
        <button className="list-group-item d-flex align-items-center gap-2">
          <span>📄</span> All Reports
        </button>
        <button className="list-group-item d-flex align-items-center gap-2">
          <span>⚙️</span> Settings
        </button>
        <button className="list-group-item d-flex align-items-center gap-2">
          <span>🕘</span> Recent
        </button>
        <button className="list-group-item d-flex align-items-center gap-2">
          <span>➕</span> Generate New
        </button>
      </div>

      <h6>Categories</h6>
      <div className="ps-1 d-flex flex-column gap-1 " style={{color:"black"}} >
        <div><input type="checkbox" id="cat1" /> <label htmlFor="cat1">AML Reports</label></div>
        <div><input type="checkbox" id="cat2" /> <label htmlFor="cat2">Risk Reports</label></div>
        <div><input type="checkbox" id="cat3" /> <label htmlFor="cat3">Customer Reports</label></div>
      </div>
    </aside>
  );
}
