import React from "react";
import "./AdminSettingsUI.css"; // Import CSS file

export default function AdminSettingsUI() {
    return (
        <div className="settings-container">

            <aside className="sidebar">
                <div className="logo">Standard Chartered</div>
                <nav className="menu">
                    <a className="menu-item active">User Management</a>
                    <a className="menu-item">Reports</a>
                    <a className="menu-item">Compliance</a>
                    <a className="menu-item">System Settings</a>
                </nav>
                <div className="logout">Logout</div>
            </aside>

            <main className="main-content">
                <div className="header">
                    <h1>Admin Settings – User Management</h1>
                    <div className="admin-profile">Admin</div>
                </div>
                <div className="card">
                    <h2>Assign Users to Active Directory Groups</h2>
                    <div className="form-grid">
                        <select>
                            <option>Select User</option>
                            <option>John Smith</option>
                            <option>Priya Sharma</option>
                            <option>David Lee</option>
                        </select>

                        <select>
                            <option>Select AD Group</option>
                            <option>Wealth Compliance</option>
                            <option>Wealth User Admin</option>
                            <option>Global User Admin</option>
                        </select>
                    </div>
                    <div className="form-actions">
                        <button className="btn-primary">Assign Access</button>
                    </div>
                </div>
                <div className="card">
                    <h2>Existing User Access</h2>
                    <table>
                        <thead>
                            <tr>
                                <th>User Name</th>
                                <th>AD Group</th>
                                <th>Access Folder</th>
                                <th>Reports</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>John Smith</td>
                                <td>Wealth Compliance</td>
                                <td>Compliance</td>
                                <td>KYC Reports, AML Reports</td>
                            </tr>
                            <tr>
                                <td>Priya Sharma</td>
                                <td>Wealth User Admin</td>
                                <td>Global User</td>
                                <td>Active User, Inactive User</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </main>
        </div>
    );
}
