import logo from "../Assests/Admin.jpg";
import { Link } from 'react-router-dom';
function Adminlogin() {
    return (
        <div class="container-fluid d-flex align-items-center justify-content-center" style={{
            background: "linear-gradient(-45deg, #007b5e, #00a884, #00bcd4, #4cafef)",
            backgroundSize: "400% 400%",
            animation: "gradientBG 8s ease infinite",
        }}>
            <style>
                {`
          @keyframes gradientBG {
            0% {background-position: 0% 50%;}
            50% {background-position: 100% 50%;}
            100% {background-position: 0% 50%;}
          }
        `}
            </style>

            <div style={{ maxWidth: "500px", width: "100%", margin: "0 auto" }}>
                <div class="card text-center mt-5 mb-5">
                    <div class="card-body" style={{ backgroundColor: "#0055a5" }}>
                        <img class="card-img-top rounded-pill" src={logo} alt="Card image" style={{ width: '100px' }} />
                        <h4 class="text-light">Admin Login</h4>
                        <form>
                            <div class="mb-3 mt-3">
                                <input type="text" class="form-control" id="useid" placeholder="Enter Admin ID" name="useid" required />
                            </div>
                            <div class="mb-3 mt-3">
                                <input type="email" class="form-control" id="email" placeholder="Enter email" name="email" required />
                            </div>
                            <div class="mb-3">
                                <input type="password" class="form-control" id="pwd" placeholder="Enter password" name="pswd" required />
                            </div>
                            <div className="mt-2 text-end">
                                <Link to="/ForgotPassword" class="text-light">Forgot password</Link>
                            </div>
                            <Link to="/AdminDashboard" type="submit" class="btn btn-primary">Login</Link>
                        </form>
                        <br></br>
                        <div>
                            <Link to="/CreateAccount" class="btn btn-info">Sign up/Create Account</Link>
                        </div>
                    </div>



                </div>

            </div>

        </div>
    )
}
export default Adminlogin;