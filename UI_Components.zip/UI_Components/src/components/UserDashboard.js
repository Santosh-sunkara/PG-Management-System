import React from "react";
import "../../node_modules/bootstrap/dist/css/bootstrap.min.css";
import "./User1.css"; // <-- Import CSS here
import { Link } from "react-router-dom";

import {
  FaUser,
  FaSearch,
  FaFileAlt,
  FaCog,
  FaClock,
  FaChartBar,
  FaBookmark,
  FaCalendarAlt,
} from "react-icons/fa";
import logo from "../Assests/Logoseema.jpg";

export default function UserDashboard() {
  return (
    <div className="bg-white min-vh-100">
      {/* Top green banner */}
      <div className="top-banner">
        <div className="container-fluid d-flex align-items-center justify-content-between ps-0">
          <img src={logo} alt="logo" className="logo-img" />
          <div className="fw-bold fs-5 text-center flex-grow-1">
            USER DASHBOARD
          </div>
          <div style={{ width: 48 }} /> {/* Spacer */}
        </div>
      </div>

      {/* Search row */}
      <div className="container-fluid py-3 border-bottom">
        <div className="row align-items-center">
          <div className="col-md-12 d-flex justify-content-end align-items-center gap-2">
            <div className="input-group" style={{ maxWidth: 360 }}>
              <input
                type="text"
                className="form-control"
                placeholder="Search reports..."
                aria-label="Search reports"
              />
              <button className="btn search-btn" aria-label="Search">
                <FaSearch />
              </button>
            </div>
            <FaUser className="ms-2" />
            <span className="ms-1 me-2">Username</span>
            <button className="btn btn-sm logout-btn">Logout</button>
          </div>
        </div>

        {/* Navigation links */}
        <div className="row mt-3">
          <div className="col d-flex gap-4 ps-md-5">
            <a href="#" className="text-decoration-none text-dark">
              Reports
            </a>
            <Link to="/bookmarks" className="text-decoration-none text-dark">
              MyBookMarks
            </Link>
            <a href="#" className="text-decoration-none text-dark">
              Recent
            </a>
            <a href="#" className="text-decoration-none text-dark">
              Profile
            </a>
          </div>
        </div>
      </div>

      {/* Main area */}
      <div className="container-fluid py-3">
        <div className="row g-4">
          {/* Sidebar */}
          <div className="col-lg-3">
            <div className="p-3 rounded shadow-sm sidebar-panel">
              <h6 className="fw-bold mb-3">Quick Access</h6>
              <button className="btn quick-btn">
                <FaFileAlt className="me-2 text-dark" /> All Reports
              </button>
              <Link to="/UserSettings" className="btn quick-btn">
                <FaCog className="me-2 text-dark" /> Settings
              </Link>
              <button className="btn quick-btn">
                <FaClock className="me-2 text-dark" /> Recent
              </button>
              <button className="btn quick-btn mb-3">
                <FaChartBar className="me-2 text-dark" /> Generate New
              </button>

              <h6 className="fw-bold mb-2">Categories</h6>
              <div className="form-check mb-2">
                <input className="form-check-input" type="checkbox" id="aml" />
                <label className="form-check-label" htmlFor="aml">
                  AML Reports
                </label>
              </div>
              <div className="form-check mb-2">
                <input className="form-check-input" type="checkbox" id="risk" />
                <label className="form-check-label" htmlFor="risk">
                  Risk Reports
                </label>
              </div>
              <div className="form-check">
                <input className="form-check-input" type="checkbox" id="cust" />
                <label className="form-check-label" htmlFor="cust">
                  Customer Reports
                </label>
              </div>
            </div>
          </div>

          {/* Right content */}
          <div className="col-lg-9">
            <div className="p-3 rounded mb-4 shadow-sm bg-white border">
              <h5 className="fw-bold mb-3 d-flex align-items-center">
                <FaCalendarAlt className="me-2" /> Latest Report Notifications
              </h5>
              <div className="placeholder-box">No new notifications.</div>
            </div>

            <div className="p-3 rounded shadow-sm bg-white border">
              <h5 className="fw-bold mb-3 d-flex align-items-center">
                <FaBookmark className="me-2" /> Recently Accessed Reports
              </h5>
              <div className="placeholder-box">No recent reports opened.</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
