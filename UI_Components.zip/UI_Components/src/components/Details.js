import React from 'react';
import './Details.css'; // import the css
// import { useLocation } from 'react-router';
import { useState } from 'react';
const Details = ({ data, setData }) => {

  const [info, setInfo] = useState(data);

 const handleEdit = (item, index) => {
    const newName = prompt("Enter new name:", item.name);
    const newEmail = prompt("Enter new email:", item.email);
    const newStatus = prompt("Enter new status (active/inactive):", item.status);
    const newAdGroup = prompt("Enter new AD Group:", item.adGroup);

    if (newName && newEmail && newStatus && newAdGroup) {
      const updated = [...info];
      updated[index] = {
        ...item,
        name: newName,
        email: newEmail,
        status: newStatus,
        adGroup: newAdGroup
      };
      setInfo(updated);
      setData(updated);
    }
  };

  const handleDelete = (i) => {
    if (window.confirm(`Are you sure you want to delete this id ${i} detail`)) {
      const newData = info.filter((det) => det.email != i.email);
      setInfo(newData);
      setData(newData);
    }
  }

  return (
    <div>
     <div className="page-header">Standard Chartered - User Management</div>
    <div className="details-container">
      <h2>User Details</h2>
      <table className="details-table">
        <thead>
          <tr>
            <th>#</th>
            <th>Name</th>
            <th>Email</th>
            <th>Status</th>
            <th>AD Group</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {info.length === 0 ? (<tr>
            <td colSpan="5" style={{ textAlign: "center" }}>
              No data available, please add a user first.
            </td>
          </tr>) : (
            info.map((i, index) => (
              <tr key={index}>
                <td>{index + 1}</td>
                <td>{i.name}</td>
                <td>{i.email}</td>
                <td className={i.status === "active" ? "status-active" : "status-inactive"}>
                  {i.status}
                </td>
                <td>{i.adGroup}</td>
                <td>
                  <button type="button" className="btn btn-success" onClick={()=> handleEdit(i,index)} style={{ marginRight: "10px" }}>Edit</button>
                  <button type="button" className="btn btn-danger" onClick={() => handleDelete(i)}>Delete</button>
                </td>
              </tr>
            ))
          )}

        </tbody>
      </table>
    </div>
    </div>
  );
};

export default Details;
