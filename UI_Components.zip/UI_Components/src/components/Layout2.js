// src/components/Layout.jsx
import { Outlet } from "react-router-dom";
import Header2 from "./Header2.js";
import Sidebar2 from "./Sidebar2.js";
import "./Bookmark.css";
export default function Layout2() {
  return (
    <>
      <Header2 />
      <div className="container-fluid app-shell">
        <div className="row h-100">
          <div className="col-12 col-md-3 col-lg-2 p-0">
            <Sidebar2 />
          </div>
          <div className="col-12 col-md-9 col-lg-10 content">
            <Outlet />
          </div>
        </div>
      </div>
    </>
  );
}
