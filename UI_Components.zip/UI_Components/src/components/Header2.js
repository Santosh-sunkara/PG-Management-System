// src/components/Header.jsx
import { NavLink } from "react-router-dom";
import logo from "../Assests/logoharshita.png";
import "./Bookmark.css";
export default function Header2() {
  return (
    <div className="topbar bg-success text-white px-3 py-2">
      <div className="d-flex align-items-center justify-content-between">
        <div className="brand d-flex align-items-center gap-2">
          <img src={logo} alt="Brand" style={{height:"35px"}
          }/>
          <span className="fw-bold">REPORTS - USER</span>
        </div>

        
          {/* Mirror of the first photo’s tabs */}
          <div className="d-flex align-items-center gap-3">
          <NavLink to="/bookmarks" className={({isActive})=> isActive ? "btn btn-sm btn-light" : "btn btn-sm btn-outline-light"}>
            MyBookMarks
          </NavLink>
          <NavLink to="/bookmarks#recent" className={({isActive})=> isActive ? "btn btn-sm btn-light" : "btn btn-sm btn-outline-light"}>
            Recent
          </NavLink>
          <NavLink to="/UserProfile" className={({isActive})=> isActive ?"btn btn-sm btn-primary" : "btn btn-sm btn-outline-secondary"}>
            Profile
          </NavLink>
        

        {/*<div className="user-actions d-flex align-items-center gap-2">
          <span className="badge badge-soft px-2">Username</span>
          <button className="btn btn-sm btn-outline-light">Logout</button>
        </div>*/}
        {/*<div className="user-actions d-flex align-items-center gap-3 ms-3">
          <span className="badge bg-secondary px-3 py-2">Username</span>
          <NavLink
            to="/profile"
            className={({isActive})=> isActive ? "btn btn-sm btn-outline-primary" : "btn-btn-sm btn-outline-secondary"}
            >
              Profile
            </NavLink>
            <button className="btn btn-sm btn-outline-danger">
              Logout
            </button>
            
      </div>*/}
      <button className="btn btn-sm-outline-danger">Logout</button>
     </div>
      </div>
    </div>
  );
}
