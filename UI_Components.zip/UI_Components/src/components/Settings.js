// src/components/Settings.js
import React, { useState } from 'react';
import "./Settings.css";


import logo from "../Assests/logokavi.png";
const Settings = () => {
  const [autoDownload, setAutoDownload] = useState(true);
  const [notifications, setNotifications] = useState({
    newReport: false,
    transferFailed: false
  });
  const [theme, setTheme] = useState('light');

  const handleNotificationChange = (type) => {
    setNotifications(prev => ({
      ...prev,
      [type]: !prev[type]
    }));
  };

  return (<>
  
    <nav className="top-banner">
      <div className="navbar-header">
        {/* Example logo image placeholder */}
        <img src={logo} alt="Logo" className="logo-img" />
        <h2 className="navbar-title-center"> USER - SETTINGS </h2>
      </div>
      
    

    </nav>

<div className="settings-container">
    
      {/* Sidebar */}
      <div className="nav-section">
        <ul>
          {['Dashboard', 'My Bookmarks', 'Reports'].map((item) => (
            <li key={item}>{item}</li>
          ))}
        </ul>
        
      
      <div className="sidebar-panel">
        <div className="quick-access">
          <h3>Quick Access</h3>
          {['All Reports', 'Settings', 'Recent', 'Generate New'].map((item) => (
            <button key={item} className="quick-btn">{item}</button>
          ))}
        

        <div className="categories">
          <h3>Categories</h3>
          <ul>
            {['AML Reports'].map(category => (
              <li key={category}><a href="#">{category}</a></li>
            ))}
          </ul>
                <div className="element">

                </div>

          <ul>
            {[ 'Risk Reports'].map(category => (
              <li key={category}><a href="#">{category}</a></li>
            ))}
            </ul>
            <div className="element">
                    
                    </div>
            
            <ul>
            {[ 'Customer Reports'].map(category => (
              <li key={category}><a href="#">{category}</a></li>
            ))}
            </ul>
        </div>
      </div>
      </div>
        </div>


                    

      {/* Main Settings */}
      
      <div className="settings-main">
      <div className="user-bar">

      <input type="text" className="settings-search" placeholder="Search..."/>
        <span className="username">User name</span>
        <button className="logout-btn">Logout</button>
        </div>  
        <div className="placeholder-box">
          <h3>Auto Download Reports After Generation</h3>
          <div>
            <button 
              className={autoDownload ? 'search-btn' : ''}
              onClick={() => setAutoDownload(true)}>
              Yes
            </button>



            <button 
              className={!autoDownload ? 'search-btn' : ''}
              onClick={() => setAutoDownload(false)}>
              No
            </button>
          </div>
        </div>

        <div className="placeholder-box">
          <h3>Email Notifications</h3>
          <div>
            {Object.entries(notifications).map(([key, value]) => (
              <label key={key}>
                <input
                  type="checkbox"
                  checked={value}
                  onChange={() => handleNotificationChange(key)}
                />
                {key === 'newReport' ? 'New Report' : 'Report Transfer Failed'}
              </label>
            ))}
          </div>
        </div>

        <div className="placeholder-box">
          <h3>Theme Option</h3>
          {['Light', 'Dark'].map(option => (
            <label key={option}>
              <input
                type="radio"
                name="theme"
                checked={theme === option.toLowerCase()}
                onChange={() => setTheme(option.toLowerCase())}
              />
              {option}
            </label>
          ))}
        </div>

        <div className="account-actions">
          <button className="search-btn">Change Password</button>
         
          <button className="search-btn">Change Username</button>
          <div className="element1"> 
          
             </div>
        </div>
      </div>
    </div>
    </>
  );
};

export default Settings;
