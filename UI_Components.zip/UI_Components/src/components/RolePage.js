import React from "react";
import profileIcon from "../Assests/Profile.jpg";
import { Link } from 'react-router-dom';
function RolePage() {
  return (
    <div
      className="d-flex justify-content-center align-items-center vh-100"
      style={{
        background: "linear-gradient(-45deg, #007b5e, #00a884, #00bcd4, #4cafef)",
        backgroundSize: "400% 400%",
        animation: "gradientBG 8s ease infinite",
      }}
    >
      <style>
        {`
          @keyframes gradientBG {
            0% {background-position: 0% 50%;}
            50% {background-position: 100% 50%;}
            100% {background-position: 0% 50%;}
          }
        `}
      </style>

      <div
        className="card shadow-lg text-center"
        style={{
          width: "350px",
          borderRadius: "20px",
          padding: "30px",
          background: "rgba(255, 255, 255, 0.95)",
          backdropFilter: "blur(6px)",
          border: "none",
        }}
      >
        <img
          src={profileIcon}
          alt="Profile Icon"
          style={{
            width: "100px",
            height: "100px",
            borderRadius: "50%",
            objectFit: "cover",
            border: "3px solid #ccc",
            marginBottom: "20px",
            display: "block",
            marginLeft: "auto",
            marginRight: "auto",
          }}
        />
        <h5 className="fw-bold mb-4" style={{ color: "#333" }}>
          Select Your Role
        </h5>

        <Link to="/Adminlogin"
          className="btn btn-outline-primary fw-bold mb-3 w-100"
          style={{ borderRadius: "10px", padding: "10px", fontSize: "16px" }}

        >
          ADMIN
        </Link>
        
        <Link to="/Userlogin"
          className="btn btn-outline-success fw-bold w-100"
          style={{ borderRadius: "10px", padding: "10px", fontSize: "16px" }}
        >
          USER
        </Link>
      </div>
    </div>
  );
}

export default RolePage;