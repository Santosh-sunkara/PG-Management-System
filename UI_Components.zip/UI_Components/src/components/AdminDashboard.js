import React from "react";
import "./AdminDashboard.css";
import logo from "../Assests/sclogoshiva.png";
import { Link } from "react-router-dom";

function AdminDashboard() {
  return (
    <div className="dashboard-container">
      {}
      <aside className="sidebar">
        <div className="logo-section">
          <img src={logo} alt="Standard Chartered" className="logo" />
        </div>
        <div className="menu-section">
          <ul>
            <li>Dashboard</li>
            <li><Link to="/AdminUser" className="text-light">User Management</Link></li>
            <li>AD Group Access</li>
            <li><Link to="/ReportAccess"  className="text-light">ReportAccess</Link></li>
            <li><Link to="/Settings" className="text-light">Settings</Link></li>
            <li>Account</li>
            <li>Help</li>
          </ul>
        </div>
      </aside>

      {}
      <main className="main-content">
        {}
        <header className="header">
          <h2>Admin Dashboard</h2>
          <div className="header-right">
            <p>Logged In as: Admin User</p>
            <button className="logout-btn">Logout</button>
          </div>
        </header>

        {}
        <section className="stats-section">
          <div className="stat-card">
            <h3>Active Users</h3>
            <p className="stat-number">12</p>
          </div>
          <div className="stat-card">
            <h3>Pending Requests</h3>
            <p className="stat-number">4</p>
          </div>
          <div className="stat-card">
            <h3>Recent Activity</h3>
            <p className="stat-number">3</p>
          </div>
        </section>

        {}
        <section className="recent-activities">
          <h3>Recent Activities</h3>
          <div className="activity-card">
            <p><strong>Admin User</strong> removed a user from AD group</p>
            <span>1 hour ago</span>
          </div>
          <div className="activity-card">
            <p><strong>Admin User</strong> added a new report</p>
            <span>3 hours ago</span>
          </div>
          <div className="activity-card">
            <p><strong>Admin User</strong> assigned access to a user</p>
            <span>1 day ago</span>
          </div>
        </section>
      </main>
    </div>
  );
}

export default AdminDashboard;